//
//  AppAnalysis.h
//  AppAnalysis
//
//  Created by Eryushion Developer on 18/02/20.
//  Copyright © 2020 Eryushion Developer. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AppAnalysis.
FOUNDATION_EXPORT double AppAnalysisVersionNumber;

//! Project version string for AppAnalysis.
FOUNDATION_EXPORT const unsigned char AppAnalysisVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppAnalysis/PublicHeader.h>


